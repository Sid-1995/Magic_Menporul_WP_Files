<?php 

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

?>
</div>



<?php 

do_action('hotelgalaxy_callout_icons_install');


do_action('hotelgalaxy_theme_footer'); 

do_action('hotelgalaxy_back_to_top'); 

wp_footer(); 

?>
</body>
</html>