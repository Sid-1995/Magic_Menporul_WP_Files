=== Hotel Sydney ===
Contributors: webdzier
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

== Installation ==

1. Go to Appearance > Themes and click the Add New button.
2. Click Upload and Choose File, then select the theme's .zip file. Click Install Now.
3. Click Activate to use your new theme right away.


== Changelog ==

= 1.0.3 =
* New WordPress tested.

= 1.0.2 =
* style.css file updated.

= 1.0.1 =
* Section title left.

== Changelog ==
= 1.0.0 =
* Initial upload

**Images**

All images from pixabay (https://pixabay.com) are licensed under  Creative Commons CC0 Public Domain.
All other images  are own creation licensed under the [GNU GPL](http://www.gnu.org/licenses/gpl-3.0.txt), version 3 or later.


*screenshot*

*  https://pixabay.com/en/summer-swimming-pool-tropical-1836046/